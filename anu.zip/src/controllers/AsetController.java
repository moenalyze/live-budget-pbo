package controllers;

import helpers.AsetHelper;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import models.Aset;
import views.*;

public class AsetController {
    Dashboard v;
    private final DefaultTableModel modelAset;
    
    public AsetController(Dashboard v) {
        String []header = {"Type", "Source", "Amount", "Note"};
        modelAset = new DefaultTableModel(header, 0);   

        refreshTable();
        this.v = v;
        v.getjTableAset().setModel(modelAset);
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        
    }
    
    private void refreshTable() {
        modelAset.setRowCount(0);
        AsetHelper helper = new AsetHelper();
        
        List<Aset> data = helper.getAllData();
        
        data.forEach((m) -> {
            modelAset.addRow(new Object[]{m.getType(), m.getSource(), m.getAmount(), m.getNotes()});
        });
    }
}
