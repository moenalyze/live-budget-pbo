package controllers;

import helpers.AsetHelper;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import helpers.TransaksiHelper;
import models.Aset;
import models.Transaksi;
import models.User;
import views.*;

public class TransaksiController {
    Dashboard v;
    private final DefaultTableModel modelTransaksi;
    
    public TransaksiController(Dashboard v) {
        String []header = {"ID", "Type", "Amount", "Date", "Description", "Source"};
        modelTransaksi = new DefaultTableModel(header, 0);

        System.out.println(User.getId());
        this.v = v;
        v.getjTableTransaksi().setModel(modelTransaksi);
        // Sembunyikan kolom ID (index ke-0)
        v.getjTableTransaksi().getColumnModel().getColumn(0).setMinWidth(0);
        v.getjTableTransaksi().getColumnModel().getColumn(0).setMaxWidth(0);
        v.getjTableTransaksi().getColumnModel().getColumn(0).setWidth(0);

        refreshTable();
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        
    }
    
    public void tambahTransaksi(String type, int amount, String description, String source) {
        TransaksiHelper helper = new TransaksiHelper();

        // Cari Aset berdasarkan source yang dipilih
        AsetHelper asetHelper = new AsetHelper();
        Aset aset = asetHelper.getAsetBySource(source);

        if (aset != null) {
            int id_aset = asetHelper.getAsetId(source);
        
            if(helper.addNewTransaksi(type, amount, description, id_aset)) {
                asetHelper.updateSaldo(id_aset, amount);
                Transaksi.total += amount;
//                Dashboard dashboard = new Dashboard(); // buat sekali
                System.out.println(Transaksi.total);
                AsetController asetController = new AsetController(v);
                refreshTable();
            } else {
                // error handle: gagal insert
            }
        } else {
            // error handle: source tidak ditemukan
            System.out.println("Aset dengan source '" + source + "' tidak ditemukan.");
        }
    }
    
    public void updateTransaksi(String type, int amount, String description, String source) {
        TransaksiHelper helper = new TransaksiHelper();
        
        // Cari Aset berdasarkan source yang dipilih
        AsetHelper asetHelper = new AsetHelper();
        Aset aset = asetHelper.getAsetBySource(source);

        if (aset != null) {
            int id_aset = asetHelper.getAsetId(source);
        
            if(helper.updateTransaksi(type, amount, description, id_aset)) {
                asetHelper.updateSaldo(id_aset, amount);
                Transaksi.total += amount;
//                Dashboard dashboard = new Dashboard(); // buat sekali
                System.out.println(Transaksi.total);
                AsetController asetController = new AsetController(v);
                refreshTable();
            } else {
                // error handle: gagal insert
            }
        } else {
            // error handle: source tidak ditemukan
            System.out.println("Aset dengan source '" + source + "' tidak ditemukan.");
        }
    }

    
    private void refreshTable() {
        modelTransaksi.setRowCount(0);
        TransaksiHelper helper = new TransaksiHelper();
        
        List<Transaksi> data = helper.getAllData();
        
        data.forEach((m) -> {
            modelTransaksi.addRow(new Object[]{m.getId(),m.getType(),m.getAmount(), m.getDate(), m.getDescription(), m.getSource()});
        });
    }
}
