package helpers;

import java.sql.*;
import java.util.*;
import models.Aset;
import models.Transaksi;
import models.User;

public class TransaksiHelper {
    private final String dbUrl = "jdbc:mysql://localhost/livebudget";
    private final String username = "root";
    private final String password = "";
    
    private Connection conn;
    private Statement stmt;
    private PreparedStatement pstmt;
    private ResultSet rs;
    private String query;
    private String deleteTransaksi = "DELETE FROM transaksi WHERE id = ? AND id_user = ?";
    private String updateTransaksi = "UPDATE transaksi SET jenis = ?, jumlah = ?, deskripsi = ? WHERE id = ? AND id_user = ?";
    
    public TransaksiHelper() {
        try {
            conn = DriverManager.getConnection(dbUrl, username, password);
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    // read data 
    public List<Transaksi> getAllData() {
        List<Transaksi> data = new ArrayList<>();
        query = "SELECT t.id, t.jenis, t.jumlah, t.tanggal, t.deskripsi, a.sumber"
                + " FROM transaksi t"
                + " JOIN aset_keuangan a ON t.id_aset = a.id"
                + " WHERE t.id_user = '" + User.getId() + "'";
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            
            while(rs.next()) {
                Transaksi transaksi = new Transaksi();
                transaksi.setId(rs.getInt("id"));
                transaksi.setType(rs.getString("jenis"));
                transaksi.setAmount(rs.getInt("jumlah"));
                transaksi.setDate(rs.getString("tanggal"));
                transaksi.setDescription(rs.getString("deskripsi"));
                transaksi.setSource(rs.getString("sumber"));
                
                data.add(transaksi);
            }
            
            stmt.close();
        } catch (SQLException e) {
        }
        
        return data; 
    }
    
    // write data
    public boolean addNewTransaksi(String type, int amount, String description, int id_aset) {
        boolean value = false;
        int id_user = User.getId();

        System.out.println("User ID: " + id_user);
        System.out.println("ID Aset: " + id_aset);

        String query = "INSERT INTO transaksi (jenis, jumlah, deskripsi, tanggal, id_user, id_aset) VALUES (?, ?, ?, CURRENT_DATE, ?, ?)";

        try {
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, type);
            pstmt.setInt(2, amount);
            pstmt.setString(3, description);
            pstmt.setInt(4, id_user);
            pstmt.setInt(5, id_aset);

            if (pstmt.executeUpdate() > 0) {
                value = true;
            }

            pstmt.close();
        } catch (SQLException e) {
            System.err.println("Gagal insert transaksi:");
            e.printStackTrace();
        }

        return value;
    }
    
    public void deleteTransaksi(int id, int id_user) {
        try {
            pstmt = conn.prepareStatement(deleteTransaksi);
            pstmt.setInt(1, id);
            pstmt.setInt(2, id_user);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean updateTransaksi(String type, int amount, String description, int id_aset) {
        boolean value = false;
        
        try {
            pstmt = conn.prepareStatement(updateTransaksi);
            pstmt.setString(1, type);
            pstmt.setInt(2, amount);
            pstmt.setString(3, description);
            pstmt.setInt(4, id_aset);
            pstmt.setInt(5, User.getId());
            pstmt.executeUpdate();
            
            if (pstmt.executeUpdate() > 0) {
                value = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return value;
    }

}
